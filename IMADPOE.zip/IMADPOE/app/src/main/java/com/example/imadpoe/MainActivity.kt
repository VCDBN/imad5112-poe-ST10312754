package com.example.imadpoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var edtNum1 = findViewById<EditText>(R.id.edtNum1)
        var edtNum2 = findViewById<EditText>(R.id.edtNum2)
        var btnAddition = findViewById<Button>(R.id.btnAddition)
        var btnSubtraction = findViewById<Button>(R.id.btnSubtraction)
        var btnMultiplication = findViewById<Button>(R.id.btnMultiplication)
        var btnDivision = findViewById<Button>(R.id.btnDivision)
        var btnSquareroot = findViewById<Button>(R.id.btnSquareRoot)
        var btnPower = findViewById<Button>(R.id.btnPower)
        var edtAnswer = findViewById<EditText>(R.id.edtAnswer)
        var btnStats = findViewById<Button>(R.id.btnStats)

        btnAddition.setOnClickListener {
            var edtNum1 = edtNum1.text.toString().toInt()
            var edtNum2 = edtNum2.text.toString().toInt()
            var edtAnswer = edtNum1 + edtNum2

        }
        btnSubtraction.setOnClickListener {
            var edtNum1 = edtNum1.text.toString().toInt()
            var edtNum2 = edtNum2.text.toString().toInt()
            var edtAnswer = edtNum1 - edtNum2
        }
        btnMultiplication.setOnClickListener {
            var edtNum1 = edtNum1.text.toString().toInt()
            var edtNum2 = edtNum2.text.toString().toInt()
            var edtAnswer = edtNum1 * edtNum2
        }
        btnDivision.setOnClickListener {
            var edtNum1 = edtNum1.text.toString().toInt()
            var edtNum2 = edtNum2.text.toString().toInt()
            var edtAnswer = edtNum1 / edtNum2
        }
        btnSquareroot.setOnClickListener {
            fun main(args: Array<String>) {

                val a = 2.3
                val b = 4
                val c = 5.6
                val root1: Double
                val root2: Double
                val output: String

                val determinant = b * b - 4.0 * a * c

                // condition for real and different roots
                if (determinant > 0) {
                    root1 = (-b + Math.sqrt(determinant)) / (2 * a)
                    root2 = (-b - Math.sqrt(determinant)) / (2 * a)

                    output = "root1 = %.2f and root2 = %.2f".format(root1, root2)
                }
                // Condition for real and equal roots
                else if (determinant == 0.0) {
                    root2 = -b / (2 * a)
                    root1 = root2

                    output = "root1 = root2 = %.2f;".format(root1)
                }
                // If roots are not real
                else {
                    val realPart = -b / (2 * a)
                    val imaginaryPart = Math.sqrt(-determinant) / (2 * a)

                    output = "root1 = %.2f+%.2fi and root2 = %.2f-%.2fi".format(realPart, imaginaryPart, realPart, imaginaryPart)
                }

                println(output)
            }
        }

        btnStats.setOnClickListener {

        }
        btnPower.setOnClickListener {
            fun main(args: Array<String>) {
                val base = 3
                var exponent = 4
                var result: Long = 1

                while (exponent != 0) {
                    result *= base.toLong()
                    --exponent
                }

                println("Answer = $result")
        }

    }

}
