package com.example.imadpoe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import kotlin.math.max
import kotlin.math.min

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        var edtNumber = findViewById<EditText>(R.id.edtNumber)
        var edtStored = findViewById<EditText>(R.id.edtStored)
        var edtResult = findViewById<EditText>(R.id.edtResult)
        var btnAdd = findViewById<Button>(R.id.btnAdd)
        var btnClear = findViewById<Button>(R.id.btnClear)
        var btnAverage = findViewById<Button>(R.id.btnAverage)
        var btnMinMax = findViewById<Button>(R.id.btnMinMax)

        btnAdd.setOnClickListener {
          var edtNumber = " "
            var edtStored = "$edtNumber, $edtNumber, $edtNumber, $edtNumber, $edtNumber, $edtNumber, $edtNumber, $edtNumber,   $edtNumber, $edtNumber"
            println("maximum amount of number are 10")
            if (edtStored > 10 )
                println("you cannot enter more than 10 numbers!")
        }
        btnClear.setOnClickListener {
            var edtStored = " "
        }
        btnAverage.setOnClickListener {
            val average = edtStored.sumOf { it."$average" } / edtStored.size
        }
        btnMinMax.setOnClickListener {
            fun getMin(arrX: Array<Int>): Int {
                var min = Int.MAX_VALUE
                for (i in arrX) {
                    min =  min.coerceAtMost(i)
                }
                return min
            }

            fun getMax(arrX: Array<Int>): Int {
                var max = Int.MIN_VALUE
                for (i in arrX) {
                    max = max.coerceAtLeast(i)
                }
                return max
            }

           println("the max number is ${getMax("${max(i)}")} and the min number is ${getMin("${min(i)}")}")

        }
    }
}
        }
    }

}