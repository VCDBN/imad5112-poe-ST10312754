package com.keenan.part1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.Example1">
        <activity
        android:name=".MainActivity"
        android:exported="true">
        <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
        </intent-filter>
        </activity>
        <activity android:name=".NewActivity"></activity>
        </application>

        var edtfirst=findViewById<EditText>(R.id.edtfirst)
        var edtmemory=findViewById<EditText>(R.id.edtmemory)
        var edtanswer=findViewById<EditText>(R.id.edtanswer)
        var btnaddd=findViewById<Button>(R.id.btnaddd)
        var btnclr=findViewById<Button>(R.id.btnclr)
        var btnaverage=findViewById<Button>(R.id.btnaverage)
        var btnminmax=findViewById<Button>(R.id.btnminmax)

        var array = arrayOf(edtfirst)
        println(array.joinToString())
        edtmemory.text = "$array"

        btnaddd.setOnClickListener {
            println("display in memory")
        }
        edtmemory.setOnClickListener {
            edtmemory.text="$edtfirst, $edtfirst, $edtfirst, $edtfirst, $edtfirst, $edtfirst, $edtfirst, $edtfirst, $edtfirst, $edtfirst"
            if (edtmemory>10)
                println("too many numbers entered maximum amount is 10")
        }
        btnclr.setOnClickListener {
            edtmemory.setText("")
        }
        btnaverage.setOnClickListener {
            fun main() {

                val average = ($edtfirst + $edtfirst) / 2
                println("Average : $average")
            }
            btnminmax.setOnClickListener {
                fun getMin(arrX: Array<Int>): Int {
                    var min = Int.MAX_VALUE
                    for (i in arrX) {
                        min =  min.coerceAtMost(i)
                    }
                    return min
                }

                fun getMax(arrX: Array<Int>): Int {
                    var max = Int.MIN_VALUE
                    for (i in arrX) {
                        max = max.coerceAtLeast(i)
                    }
                    return max
                }

                edtanswer.text = "The Min is "+ getMin(arrX)  + " and the Max is " + getMax(arrX)

            }
        }
    }
            }
        }
    }
}